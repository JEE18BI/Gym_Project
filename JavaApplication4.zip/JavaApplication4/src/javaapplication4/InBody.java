
package javaapplication4;


import java.util.Date;
import java.util.ArrayList;
import java.util.Scanner;
import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.time.Duration;
import java.io.*;

public class InBody {

   public ArrayList<String> InBodyDate = new ArrayList<>();

   public ArrayList<Double> height = new ArrayList<>();

    public ArrayList<Double> total_weight = new ArrayList<>();

    public ArrayList<Double> bodyfat_mass = new ArrayList<>();

    public ArrayList<Double> minerals = new ArrayList<>();

    public ArrayList<Double> total_body_water = new ArrayList<>();

    public ArrayList<Double> protein = new ArrayList<>();

    // setters
    public void setInBodyDate(ArrayList<String> InBodyDate) {
        this.InBodyDate = InBodyDate;
    }

    public void setheight(ArrayList<Double> height) {
        this.height = height;
    }

    public void setbodyfat_mass(ArrayList<Double> bodyfat_mass) {
        this.bodyfat_mass = bodyfat_mass;
    }

    public void settotal_weight(ArrayList<Double> total_weight) {
        this.total_weight = total_weight;
    }

    public void setminerals(ArrayList<Double> minerals) {
        this.minerals = minerals;
    }

    public void settotal_body_water(ArrayList<Double> total_body_water) {
        this.total_body_water = total_body_water;
    }
    public void setprotein(ArrayList<Double> protein) {
        this.protein = protein;
    }


    //getters
    public ArrayList<String> getInBodyDate() {
        return InBodyDate;
    }

    public ArrayList<Double> getheight() {
        return height;
    }

    public ArrayList<Double> getbodyfat_mass() {
        return bodyfat_mass;
    }

    public ArrayList<Double> gettotal_weight() {
        return total_weight;
    }

    public ArrayList<Double> gettotal_body_water() {
        return total_body_water;
    }

    public ArrayList<Double> getminerals() {
        return minerals;
    }

    public ArrayList<Double> getprotein() {
        return protein;
    }

    public void DoInBody(Customer customer, String date) throws ParseException {
        Scanner scanner = new Scanner(System.in);

        // Get customer ID from the user
        System.out.print("Enter customer ID: ");
        int customerId = scanner.nextInt();

        // Check if the customer ID exists
        int customerIndex = customer.getCustomer_ID().indexOf(customerId);
        if (customerIndex == -1) {
            System.out.println("Customer with ID " + customerId + " not found.");
            return;
        }

        // Initialize inbody details lists if they are empty
        if (getInBodyDate().isEmpty()) {
            getInBodyDate().add("");
            getheight().add(0.0);
            gettotal_weight().add(0.0);
            getbodyfat_mass().add(0.0);
            getminerals().add(0.0);
            gettotal_body_water().add(0.0);
            getprotein().add(0.0);
        }

        // Ensure that the lists have entries for the current customer
        while (getInBodyDate().size() <= customerIndex) {
            getInBodyDate().add("");
            getheight().add(0.0);
            gettotal_weight().add(0.0);
            getbodyfat_mass().add(0.0);
            getminerals().add(0.0);
            gettotal_body_water().add(0.0);
            getprotein().add(0.0);
        }

        // Check if the customer has done a previous inbody
        if (!getInBodyDate().get(customerIndex).isEmpty() && dateDifferenceCalculator(getInBodyDate().get(customerIndex), date) <= 30) {
            System.out.println("Cannot do an inbody on the same date within 30 days.");
            return;
        }

        // Get or update inbody details
        System.out.print("Enter height in meters: ");
        double customerHeight = scanner.nextDouble();
        getheight().set(customerIndex, customerHeight);

        System.out.print("Enter total weight: ");
        double customerTotalWeight = scanner.nextDouble();
        gettotal_weight().set(customerIndex, customerTotalWeight);

        System.out.print("Enter body fat mass: ");
        double customerBodyFatMass = scanner.nextDouble();
        getbodyfat_mass().set(customerIndex, customerBodyFatMass);

        System.out.print("Enter minerals: ");
        double customerMinerals = scanner.nextDouble();
        getminerals().set(customerIndex, customerMinerals);

        System.out.print("Enter total body water: ");
        double customerTotalBodyWater = scanner.nextDouble();
        gettotal_body_water().set(customerIndex, customerTotalBodyWater);

        System.out.print("Enter protein: ");
        double customerProtein = scanner.nextDouble();
        getprotein().set(customerIndex, customerProtein);

        // Update the inbody date
        getInBodyDate().set(customerIndex, date);

        // Display success message
        System.out.println("InBody details updated successfully for customer ID: " + customerId);
    }

    public void displayInBodyDetails(Customer customer) {
        Scanner scanner = new Scanner(System.in);

        // Get customer ID from the user
        System.out.print("Enter customer ID to display inbody details: ");
        int customerId = scanner.nextInt();

        // Check if the customer ID exists
        int customerIndex = customer.getCustomer_ID().indexOf(customerId);
        if (customerIndex == -1) {
            System.out.println("Customer with ID " + customerId + " not found.");
            return;
        }

        // Display inbody details
        System.out.println("InBody details for customer ID " + customerId + ":");
        System.out.println("Height: " + getheight().get(customerIndex));
        System.out.println("Total Weight: " + gettotal_weight().get(customerIndex));
        System.out.println("Body Fat Mass: " + getbodyfat_mass().get(customerIndex));
        System.out.println("Minerals: " + getminerals().get(customerIndex));
        System.out.println("Total Body Water: " + gettotal_body_water().get(customerIndex));
        System.out.println("Protein: " + getprotein().get(customerIndex));
        System.out.println("Date of Inbody: " + getInBodyDate().get(customerIndex));
    }

    public void displayWeightGoal(Customer customer) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter customer ID to display inbody details: ");
        int customerId = scanner.nextInt();

        int customerIndex = customer.getCustomer_ID().indexOf(customerId);
        if (customerIndex == -1) {
            System.out.println("Customer with ID " + customerId + " not found.");
            return;
        }

        // Get inbody details
        double height = getheight().get(customerIndex);
        double bodyWeight = gettotal_weight().get(customerIndex);

        // Calculate BMI
        double bmi = bodyWeight / Math.pow(height, 2);

        // Set target BMI (you can adjust this based on your specific target BMI)
        double targetBMI = 22.0;

        // Calculate target weight based on target BMI
        double targetWeight = targetBMI * Math.pow(height, 2);

        // Display results
        System.out.println("Customer ID: " + customerId);
        System.out.println("Current BMI: " + bmi);
        System.out.println("Target BMI: " + targetBMI);
        System.out.println("Target Weight: " + targetWeight);
    }

    public long dateDifferenceCalculator(String d, String e) throws ParseException {
        SimpleDateFormat dtobj = new SimpleDateFormat("dd-MM-yyyy");

        Date date_d = dtobj.parse(d);
        Date date_a = dtobj.parse(e);

        long daysBetween = Duration.between(date_d.toInstant(), date_a.toInstant()).toDays();

        System.out.println("Difference in days: " + daysBetween);

        return daysBetween;
    }

    public void serializeInBodyArrayLists() {
        try (PrintWriter writer = new PrintWriter(new FileWriter("/Users/ahmedosama/NetBeansProjects/JavaApplication4/InBodyFiles/height.txt"))) {
            for (Double h : height) {
                writer.println(h);
            }
            System.out.println("height serialized successfully.");
        } catch (IOException e) {
            System.out.println("Error during serialization of height: " + e.getMessage());
        }
        
        try (PrintWriter writer = new PrintWriter(new FileWriter("/Users/ahmedosama/NetBeansProjects/JavaApplication4/InBodyFiles/total_weight.txt"))) {
            for (Double weight : total_weight) {
                writer.println(weight);
            }
            System.out.println("total_weight serialized successfully.");
        } catch (IOException e) {
            System.out.println("Error during serialization of total_weight: " + e.getMessage());
        }
        
        try (PrintWriter writer = new PrintWriter(new FileWriter("/Users/ahmedosama/NetBeansProjects/JavaApplication4/InBodyFiles/bodyfat_mass.txt"))) {
            for (Double fat : bodyfat_mass) {
                writer.println(fat);
            }
            System.out.println("bodyfat_mass serialized successfully.");
        } catch (IOException e) {
            System.out.println("Error during serialization of bodyfat_mass: " + e.getMessage());
        }
        
        try (PrintWriter writer = new PrintWriter(new FileWriter("/Users/ahmedosama/NetBeansProjects/JavaApplication4/InBodyFiles/minerals.txt"))) {
            for (Double m : minerals) {
                writer.println(m);
            }
            System.out.println("minerals serialized successfully.");
        } catch (IOException e) {
            System.out.println("Error during serialization of minerals: " + e.getMessage());
        }
        
        try (PrintWriter writer = new PrintWriter(new FileWriter("/Users/ahmedosama/NetBeansProjects/JavaApplication4/InBodyFiles/total_body_water.txt"))) {
            for (Double water : total_body_water) {
                writer.println(water);
            }
            System.out.println("total_body_water serialized successfully.");
        } catch (IOException e) {
            System.out.println("Error during serialization of total_body_water: " + e.getMessage());
        }
        
        try (PrintWriter writer = new PrintWriter(new FileWriter("/Users/ahmedosama/NetBeansProjects/JavaApplication4/InBodyFiles/protein.txt"))) {
            for (Double p : protein) {
                writer.println(p);
            }
            System.out.println("protein serialized successfully.");
        } catch (IOException e) {
            System.out.println("Error during serialization of protein: " + e.getMessage());
        }
        
        try (PrintWriter writer = new PrintWriter(new FileWriter("/Users/ahmedosama/NetBeansProjects/JavaApplication4/InBodyFiles/InBodyDate.txt"))) {
            for (String date : InBodyDate) {
                writer.println(date);
            }
            System.out.println("InBodyDate serialized successfully.");
        } catch (IOException e) {
            System.out.println("Error during serialization of InBodyDate: " + e.getMessage());
        }
    }
    public void deserializeInBodyArrayLists() {
        try (BufferedReader reader = new BufferedReader(new FileReader("/Users/ahmedosama/NetBeansProjects/JavaApplication4/InBodyFiles/height.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.isEmpty()) {
                height.add(Double.parseDouble(line));
                }
            }
            System.out.println("height deserialized successfully.");
        } catch (IOException | NumberFormatException e) {
            System.out.println("Error during deserialization of height: " + e.getMessage());
        }
        
        try (BufferedReader reader = new BufferedReader(new FileReader("/Users/ahmedosama/NetBeansProjects/JavaApplication4/InBodyFiles/total_weight.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.isEmpty()) {
                total_weight.add(Double.parseDouble(line));
                }
            }
            System.out.println("total_weight deserialized successfully.");
        } catch (IOException | NumberFormatException e) {
            System.out.println("Error during deserialization of total_weight: " + e.getMessage());
        }
        
        try (BufferedReader reader = new BufferedReader(new FileReader("/Users/ahmedosama/NetBeansProjects/JavaApplication4/InBodyFiles/bodyfat_mass.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.isEmpty()) {
                bodyfat_mass.add(Double.parseDouble(line));
                }
            }
            System.out.println("bodyfat_mass deserialized successfully.");
        } catch (IOException | NumberFormatException e) {
            System.out.println("Error during deserialization of bodyfat_mass: " + e.getMessage());
        }
        
        try (BufferedReader reader = new BufferedReader(new FileReader("/Users/ahmedosama/NetBeansProjects/JavaApplication4/InBodyFiles/minerals.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.isEmpty()) {
                minerals.add(Double.parseDouble(line));
                } 
            }
            System.out.println("minerals deserialized successfully.");
        } catch (IOException | NumberFormatException e) {
            System.out.println("Error during deserialization of minerals: " + e.getMessage());
        }
        
        try (BufferedReader reader = new BufferedReader(new FileReader("/Users/ahmedosama/NetBeansProjects/JavaApplication4/InBodyFiles/total_body_water.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.isEmpty()) {
                total_body_water.add(Double.parseDouble(line));
                }
            }
            System.out.println("total_body_water deserialized successfully.");
        } catch (IOException | NumberFormatException e) {
            System.out.println("Error during deserialization of total_body_water: " + e.getMessage());
        }
        
        try (BufferedReader reader = new BufferedReader(new FileReader("/Users/ahmedosama/NetBeansProjects/JavaApplication4/InBodyFiles/protein.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.isEmpty()) {
                protein.add(Double.parseDouble(line));
                }
            }
            System.out.println("protein deserialized successfully.");
        } catch (IOException | NumberFormatException e) {
            System.out.println("Error during deserialization of protein: " + e.getMessage());
        }
        
        try (BufferedReader reader = new BufferedReader(new FileReader("/Users/ahmedosama/NetBeansProjects/JavaApplication4/InBodyFiles/InBodyDate.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                InBodyDate.add(line);
            }
            System.out.println("InBodyDate deserialized successfully.");
        } catch (IOException e) {
            System.out.println("Error during deserialization of InBodyDate: " + e.getMessage());
        }
    }

}