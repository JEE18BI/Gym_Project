/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication4;

/**
 *
 * @author ahmedosama
 */
import java.util.*;
import java.io.*;


public class Customer {

    Coach coach = new Coach();
    Subscription subscription = new Subscription();
    //array Lists
    static ArrayList<Integer> Customer_ID = new ArrayList<>();

    ArrayList<String> Customer_Password = new ArrayList<>();

    static ArrayList<String> Customer_Name = new ArrayList<>();

    public ArrayList<String> Customer_Gender = new ArrayList<>();

    public ArrayList<Integer> Customer_Age = new ArrayList<>();

    public ArrayList<String> Customer_Email = new ArrayList<>();

    public ArrayList<String> Customer_Address = new ArrayList<>();

    private ArrayList<Integer> Customer_PhoneNumber = new ArrayList<>();

    public ArrayList<Integer> Customer_AssignedCoach = new ArrayList<>(); // Add this for coach assignment

    public ArrayList<String> Customer_RegistrationDate = new ArrayList<>();

    public ArrayList<Integer> getCustomer_Age() {
        return Customer_Age;
    }

    public ArrayList<String> getCustomer_Address() {
        return Customer_Address;
    }
//objects from other classes
    //private Equipment equipment;
    //private MembershipPlan membership;
    //private InBody inbody;

    //getters

    public ArrayList<Integer> getCustomer_AssignedCoach() {
        return Customer_AssignedCoach;
    }

    public ArrayList<Integer> getCustomer_ID() {
        return Customer_ID;
    }

    public ArrayList<String> getCustomer_Name() {
        return Customer_Name;
    }
    
    public ArrayList<String> getCustomer_Password() {
        return Customer_Password;
    }

    public ArrayList<String> getCustomer_Gender() {
        return Customer_Gender;
    }

    public ArrayList<String> getCustomer_Email() {
        return Customer_Email;
    }

    public ArrayList<String> getAddress() {
        return Customer_Address;
    }

    public ArrayList<Integer> getCustomer_PhoneNumber() {
        return Customer_PhoneNumber;
    }

    public ArrayList<String> getCustomer_RegistrationDate() {
        return Customer_RegistrationDate;
    }

    public Coach getCoach() {
        return coach;
    }

    public Subscription getSubscription() {
        return subscription;
    }
    //setters

    public void setCustomer_ID(ArrayList<Integer> Customer_ID) {
        this.Customer_ID = Customer_ID;
    }

    public void setCustomer_Name(ArrayList<String> Customer_Name) {
        this.Customer_Name = Customer_Name;
    }
    
    public void setCustomer_AssignedCoach(ArrayList<Integer> Customer_AssignedCoach) {
        this.Customer_AssignedCoach = Customer_AssignedCoach;
    }
    
    public void setCustomer_Password(ArrayList<String> Customer_Password) {
        this.Customer_Password = Customer_Password;
    }

    public void setCustomer_Gender(ArrayList<String> Customer_Gender) {
        this.Customer_Gender = Customer_Gender;
    }

    public void setCustomer_Email(ArrayList<String> Customer_Email) {
        this.Customer_Email = Customer_Email;
    }

    public void setAddress(ArrayList<String> Address) {
        this.Customer_Address = Address;
    }

    public void setCustomer_PhoneNumber(ArrayList<Integer> Customer_PhoneNumber) {
        this.Customer_PhoneNumber = Customer_PhoneNumber;
    }
    
    public void setCustomer_Age(ArrayList<Integer> Customer_Age) {
        this.Customer_Age = Customer_Age;
    }

    public void setCustomer_RegistrationDate(String registrationDate) {
        this.Customer_RegistrationDate.add(registrationDate);
    }

    //methods
    public void Add_Customer(String date) {
    int id;
    int age;
    String name;
    String address;
    int phone;
    String email;
    int coachChoose;
    String gender;
    boolean validCoach = false;

    Scanner input = new Scanner(System.in);

    while (!validCoach) {
        // Display coach id and name
        System.out.println("Available Coaches:");
        for (int i = 0; i < Coach.getCoach_ID().size(); i++) {
            int coachId = Coach.getCoach_ID().get(i);
            String coachName = Coach.getCoach_Name().get(i);

            // Check if the coach has less than 10 customers
            if (Coach.getCoach_ID().contains(coachId) && coach.getCustomerCountForCoach(coachId, this) < 10) {
                System.out.print("Coach ID:" + coachId);
                System.out.println(" ----->   Coach Name: " + coachName);
            }
        }

        System.out.println("Choose a coach ID for the customer:");
        int chosenCoachId = input.nextInt();

        // Check if the chosen coach exists and has less than 10 customers
        if (Coach.getCoach_ID().contains(chosenCoachId) && coach.getCustomerCountForCoach(chosenCoachId, this) < 10) {
            setCustomer_AssignedCoach(addIntegerToList(getCustomer_AssignedCoach(), chosenCoachId));
            System.out.println("Customer assigned to Coach ID: " + chosenCoachId);
            validCoach = true;
        } else {
            System.out.println("Invalid coach ID or coach has reached the maximum number of customers. Customer not assigned.");
        }
    }

    boolean validId = false;

    while (!validId) {
        try {
            System.out.println("Enter customer ID:");
            id = input.nextInt();
            input.nextLine();
            if (getCustomer_ID().contains(id)) {
                System.out.println("Customer with ID " + id + " already exists. Please enter a different ID.");
            } else {
                setCustomer_ID(addIntegerToList(getCustomer_ID(), id));
                validId = true;
            }
        } catch (InputMismatchException e) {
            System.out.println("Invalid input. Please enter valid numeric values.");
            // Consume the invalid input
            input.nextLine();
        }
    }

    System.out.println("Enter customer password:");
    String pass = input.nextLine();
    setCustomer_Password(addStringToList(getCustomer_Password(), pass));

    System.out.println("Enter customer gender (Male - Female):");
    gender = input.nextLine();
    setCustomer_Gender(addStringToList(getCustomer_Gender(), gender));

    System.out.println("Enter customer age:");
    age = input.nextInt();
    setCustomer_Age(addIntegerToList(getCustomer_Age(), age));
    input.nextLine();

    System.out.println("Enter customer address:");
    address = input.nextLine();
    setAddress(addStringToList(getCustomer_Address(), address));

    boolean validName = false;
    while (!validName) {
        try {
            System.out.println("Enter customer name:");
            name = input.nextLine();

            if (!name.trim().isEmpty() && !name.matches(".*\\d.*")) {
                // Check if the name is not empty and does not contain any digits
                setCustomer_Name(addStringToList(getCustomer_Name(), name));
                validName = true;
            } else {
                throw new IllegalArgumentException("Invalid name. Please enter a non-empty name without numbers.");
            }
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        }
    }

    System.out.println("Enter customer email:");
    email = input.nextLine();
    setCustomer_Email(addStringToList(getCustomer_Email(), email));

    setCustomer_RegistrationDate(date);
}


    // Helper methods for adding values to lists

    private ArrayList<Integer> addIntegerToList(ArrayList<Integer> list, int value) {
        list.add(value);
        return list;
    }

    private ArrayList<String> addStringToList(ArrayList<String> list, String value) {
        list.add(value);
        return list;
    }


    public void Edit_Customer() {
        Scanner input = new Scanner(System.in);

        System.out.println("Enter the customer ID to edit:");
        int idToEdit = input.nextInt();

        int index = Customer_ID.indexOf(idToEdit);

        if (index != -1) {
            System.out.println("Editing customer with ID: " + idToEdit);

            // You can choose which information to edit
            System.out.println("1. Edit Name");
            System.out.println("2. Edit Address");
            System.out.println("3. Edit Email");
            System.out.println("4. Edit Age");

            int choice = input.nextInt();
            input.nextLine();  // Consume the newline character

            switch (choice) {
                case 1:
                    System.out.println("Enter new name:");
                    String newName = input.nextLine();
                    Customer_Name.set(index, newName);
                    break;
                case 2:
                    System.out.println("Enter new address:");
                    String newAddress = input.nextLine();
                    Customer_Address.set(index, newAddress);
                    break;
                case 3:
                    System.out.println("Enter new email:");
                    String newEmail = input.nextLine();
                    Customer_Email.set(index, newEmail);
                    break;
                case 4:
                    System.out.println("Enter new age:");
                    int newAge = input.nextInt();
                    Customer_Age.set(index, newAge);
                    break;
                default:
                    System.out.println("Invalid choice.");
            }

            System.out.println("Customer information updated:");
            System.out.println("ID: " + Customer_ID.get(index));
            System.out.println("Name: " + Customer_Name.get(index));
            System.out.println("Address: " + Customer_Address.get(index));
            System.out.println("Email: " + Customer_Email.get(index));
            System.out.println("Age: " + Customer_Age.get(index));
        } else {
            System.out.println("Customer with ID " + idToEdit + " not found.");
        }
    }


    //delete
    public void Delete_Customer() {
        Scanner input = new Scanner(System.in);

        System.out.println("Enter the customer ID to delete:");
        int idToDelete = input.nextInt();

        int index = Customer_ID.indexOf(idToDelete);

        if (index != -1) {
            System.out.println("Deleting customer with ID: " + idToDelete);

            // Display the customer information before deletion
            System.out.println("Customer information to be deleted:");
            System.out.println("ID: " + Customer_ID.get(index));
            System.out.println("Age: " + Customer_Age.get(index));
            System.out.println("Gender: " + Customer_Gender.get(index));
            System.out.println("Name: " + Customer_Name.get(index));
            System.out.println("Address: " + Customer_Address.get(index));
            System.out.println("Email: " + Customer_Email.get(index));

            // Remove the customer from the lists
            Customer_ID.remove(index);
            Customer_Name.remove(index);
            Customer_Address.remove(index);
            Customer_Email.remove(index);
            Customer_Gender.remove(index);
            Customer_Age.remove(index);

            System.out.println("Customer deleted successfully.");
        } else {
            System.out.println("Customer with ID " + idToDelete + " not found.");
        }
    }


    public void DisplayCoachForCustomer ( int customerId){
        int index = Customer_ID.indexOf(customerId);
        if (index != -1) {
            int coachId = Customer_AssignedCoach.get(index);
            System.out.println("Customer ID " + customerId + " is trained by Coach ID " + coachId);
        } else {
            System.out.println("Customer with ID " + customerId + " not found.");
        }
    }

    public void displayAssignedCoachDetails(Coach coach) {
        Scanner input = new Scanner(System.in);

        // Prompt for Customer ID
        System.out.println("Enter Customer ID:");
        int customerId = input.nextInt();

        // Check if the customer exists
        if (Customer_ID.contains(customerId)) {
            int assignedCoachId = Customer_AssignedCoach.get(Customer_ID.indexOf(customerId));

            // Check if the assigned coach exists
            if (Coach.Coach_ID.contains(assignedCoachId)) {
                int coachIndex = Coach.Coach_ID.indexOf(assignedCoachId);

                // Display Coach Details
                System.out.println("Assigned Coach Details:");
                System.out.println("Coach ID: " + Coach.Coach_ID.get(coachIndex));
                System.out.println("Coach Name: " + Coach.Coach_Name.get(coachIndex));
                System.out.println("Coach Email: " + Coach.getCoach_Email().get(coachIndex));
                System.out.println("Coach Phone Number: " + Coach.Coach_PhoneNumber.get(coachIndex));
            } else {
                System.out.println("Assigned Coach not found for Customer ID " + customerId);
            }
        } else {
            System.out.println("Customer with ID " + customerId + " not found.");
        }
    }

    private int numberOfSubscriptions = 0;

    // ... existing code ...

    // Increment the number of subscriptions when a customer subscribes
    public void incrementSubscriptionCount() {
        numberOfSubscriptions++;
    }

    // Get the number of subscriptions for a customer
    public int getNumberOfSubscriptions() {
        return numberOfSubscriptions;
    }

    public void serializeCustomerArrayLists() {
        try (PrintWriter writer = new PrintWriter(new FileWriter("/Users/ahmedosama/NetBeansProjects/JavaApplication4/CustomerFiles/Customer_ID.txt"))) {
            for (Integer id : Customer_ID) {
                writer.println(id);
            }
            System.out.println("Customer_ID serialized successfully.");
        } catch (IOException e) {
            System.out.println("Error during serialization of Customer_ID: " + e.getMessage());
        }

        try (PrintWriter writer = new PrintWriter(new FileWriter("/Users/ahmedosama/NetBeansProjects/JavaApplication4/CustomerFiles/Customer_Name.txt"))) {
            for (String name : Customer_Name) {
                writer.println(name);
            }
            System.out.println("Customer_Name serialized successfully.");
        } catch (IOException e) {
            System.out.println("Error during serialization of Customer_Name: " + e.getMessage());
        }

        try (PrintWriter writer = new PrintWriter(new FileWriter("/Users/ahmedosama/NetBeansProjects/JavaApplication4/CustomerFiles/Customer_Password.txt"))) {
            for (String pass : Customer_Password) {
                writer.println(pass);
            }
            System.out.println("Customer_Password serialized successfully.");
        } catch (IOException e) {
            System.out.println("Error during serialization of Customer_Password: " + e.getMessage());
        }

        try (PrintWriter writer = new PrintWriter(new FileWriter("/Users/ahmedosama/NetBeansProjects/JavaApplication4/CustomerFiles/Customer_Gender.txt"))) {
            for (String gender : Customer_Gender) {
                writer.println(gender);
            }
            System.out.println("Customer_Gender serialized successfully.");
        } catch (IOException e) {
            System.out.println("Error during serialization of Customer_Gender: " + e.getMessage());
        }

        try (PrintWriter writer = new PrintWriter(new FileWriter("/Users/ahmedosama/NetBeansProjects/JavaApplication4/CustomerFiles/Customer_Age.txt"))) {
            for (Integer age : Customer_Age) {
                writer.println(age);
            }
            System.out.println("Customer_Age serialized successfully.");
        } catch (IOException e) {
            System.out.println("Error during serialization of Customer_Age: " + e.getMessage());
        }

        try (PrintWriter writer = new PrintWriter(new FileWriter("/Users/ahmedosama/NetBeansProjects/JavaApplication4/CustomerFiles/Customer_Email.txt"))) {
            for (String email : Customer_Email) {
                writer.println(email);
            }
            System.out.println("Customer_Email serialized successfully.");
        } catch (IOException e) {
            System.out.println("Error during serialization of Customer_Email: " + e.getMessage());
        }

        try (PrintWriter writer = new PrintWriter(new FileWriter("/Users/ahmedosama/NetBeansProjects/JavaApplication4/CustomerFiles/Customer_Address.txt"))) {
            for (String address : Customer_Address) {
                writer.println(address);
            }
            System.out.println("Customer_Address serialized successfully.");
        } catch (IOException e) {
            System.out.println("Error during serialization of Customer_Address: " + e.getMessage());
        }

        try (PrintWriter writer = new PrintWriter(new FileWriter("/Users/ahmedosama/NetBeansProjects/JavaApplication4/CustomerFiles/Customer_PhoneNumber.txt"))) {
            for (Integer num : Customer_PhoneNumber) {
                writer.println(num);
            }
            System.out.println("Customer_PhoneNumber serialized successfully.");
        } catch (IOException e) {
            System.out.println("Error during serialization of Customer_PhoneNumber: " + e.getMessage());
        }

        try (PrintWriter writer = new PrintWriter(new FileWriter("/Users/ahmedosama/NetBeansProjects/JavaApplication4/CustomerFiles/Customer_AssignedCoach.txt"))) {
            for (Integer coachid : Customer_AssignedCoach) {
                writer.println(coachid);
            }
            System.out.println("Customer_AssignedCoach serialized successfully.");
        } catch (IOException e) {
            System.out.println("Error during serialization of Customer_AssignedCoach: " + e.getMessage());
        }

        try (PrintWriter writer = new PrintWriter(new FileWriter("/Users/ahmedosama/NetBeansProjects/JavaApplication4/CustomerFiles/Customer_RegistrationDate.txt"))) {
            for (String date : Customer_RegistrationDate) {
                writer.println(date);
            }
            System.out.println("Customer_RegistrationDate serialized successfully.");
        } catch (IOException e) {
            System.out.println("Error during serialization of Customer_RegistrationDate: " + e.getMessage());
        }

    }

    public void deserializeCustomerArrayLists() {
        try (BufferedReader reader = new BufferedReader(new FileReader("/Users/ahmedosama/NetBeansProjects/JavaApplication4/CustomerFiles/Customer_ID.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                Customer_ID.add(Integer.parseInt(line));
            }
            System.out.println("Customer_ID deserialized successfully.");
        } catch (IOException | NumberFormatException e) {
            System.out.println("Error during deserialization of Customer_ID: " + e.getMessage());
        }

        try (BufferedReader reader = new BufferedReader(new FileReader("/Users/ahmedosama/NetBeansProjects/JavaApplication4/CustomerFiles/Customer_Password.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                Customer_Password.add(line);
            }
            System.out.println("Customer_Password deserialized successfully.");
        } catch (IOException e) {
            System.out.println("Error during deserialization of Customer_Password: " + e.getMessage());
        }

        try (BufferedReader reader = new BufferedReader(new FileReader("/Users/ahmedosama/NetBeansProjects/JavaApplication4/CustomerFiles/Customer_Name.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                Customer_Name.add(line);
            }
            System.out.println("Customer_Name deserialized successfully.");
        } catch (IOException e) {
            System.out.println("Error during deserialization of Customer_Name: " + e.getMessage());
        }

        try (BufferedReader reader = new BufferedReader(new FileReader("/Users/ahmedosama/NetBeansProjects/JavaApplication4/CustomerFiles/Customer_Gender.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                Customer_Gender.add(line);
            }
            System.out.println("Customer_Gender deserialized successfully.");
        } catch (IOException e) {
            System.out.println("Error during deserialization of Customer_Gender: " + e.getMessage());
        }

        try (BufferedReader reader = new BufferedReader(new FileReader("/Users/ahmedosama/NetBeansProjects/JavaApplication4/CustomerFiles/Customer_Age.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                Customer_Age.add(Integer.parseInt(line));
            }
            System.out.println("Customer_Age deserialized successfully.");
        } catch (IOException | NumberFormatException e) {
            System.out.println("Error during deserialization of Customer_Age: " + e.getMessage());
        }

        try (BufferedReader reader = new BufferedReader(new FileReader("/Users/ahmedosama/NetBeansProjects/JavaApplication4/CustomerFiles/Customer_Email.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                Customer_Email.add(line);
            }
            System.out.println("Customer_Email deserialized successfully.");
        } catch (IOException e) {
            System.out.println("Error during deserialization of Customer_Email: " + e.getMessage());
        }

        try (BufferedReader reader = new BufferedReader(new FileReader("/Users/ahmedosama/NetBeansProjects/JavaApplication4/CustomerFiles/Customer_Address.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                Customer_Address.add(line);
            }
            System.out.println("Customer_Address deserialized successfully.");
        } catch (IOException e) {
            System.out.println("Error during deserialization of Customer_Address: " + e.getMessage());
        }

        try (BufferedReader reader = new BufferedReader(new FileReader("/Users/ahmedosama/NetBeansProjects/JavaApplication4/CustomerFiles/Customer_PhoneNumber.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                Customer_PhoneNumber.add(Integer.parseInt(line));
            }
            System.out.println("Customer_PhoneNumber deserialized successfully.");
        } catch (IOException | NumberFormatException e) {
            System.out.println("Error during deserialization of Customer_PhoneNumber: " + e.getMessage());
        }

        try (BufferedReader reader = new BufferedReader(new FileReader("/Users/ahmedosama/NetBeansProjects/JavaApplication4/CustomerFiles/Customer_AssignedCoach.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                Customer_AssignedCoach.add(Integer.parseInt(line));
            }
            System.out.println("Customer_AssignedCoach deserialized successfully.");
        } catch (IOException | NumberFormatException e) {
            System.out.println("Error during deserialization of Customer_AssignedCoach: " + e.getMessage());
        }

        try (BufferedReader reader = new BufferedReader(new FileReader("/Users/ahmedosama/NetBeansProjects/JavaApplication4/CustomerFiles/Customer_RegistrationDate.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                Customer_RegistrationDate.add(line);
            }
            System.out.println("Customer_RegistrationDate deserialized successfully.");
        } catch (IOException e) {
            System.out.println("Error during deserialization of Customer_RegistrationDate: " + e.getMessage());
        }
    }

    public boolean customerlogin() {
        Scanner input = new Scanner(System.in);

        System.out.println("Enter Customer ID:");
        int customerId = input.nextInt();
        input.nextLine();  // Consume the newline character

        System.out.println("Enter Password:");
        String password = input.nextLine();

        // Check if the provided ID and password match
        int index = Customer_ID.indexOf(customerId);
        if (index != -1 && Customer_Password.get(index).equals(password)) {
            System.out.println("Login successful. Welcome, " + Customer_Name.get(index) + "!");
            return true;
        } else {
            System.out.println("Invalid Customer ID or Password. Login failed.");
            return false;
        }
    }
}
