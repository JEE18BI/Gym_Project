package javaapplication4;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class FeedbackApp implements Serializable {

    private int userId;
    private String comment;
    private List<FeedbackApp> feedbackList;

    public FeedbackApp(int userId, String comment) {
        this.userId = userId;
        this.comment = comment;
    }

    public FeedbackApp() {
        feedbackList = new ArrayList<>();
    }

    public int getUserId() {
        return userId;
    }

    public String getComment() {
        return comment;
    }

    // Add feedback for a user
    void addFeedback(int userId, String comment) {
        feedbackList.add(new FeedbackApp(userId, comment));
        System.out.println("Feedback received from User ID " + userId + ": " + comment);
    }

    // Display all feedback
    void displayFeedback() {
        if (feedbackList.isEmpty()) {
            System.out.println("No feedback available.");
        } else {
            System.out.println("User Feedback:");
            for (FeedbackApp feedback : feedbackList) {
                System.out.println("User ID: " + feedback.getUserId());
                System.out.println("Feedback: " + feedback.getComment());
                System.out.println("----------------------------");
            }
        }
    }

    // Serialize feedbackList to a file
    void serializeFeedbackList() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("FeedbackAppFiles/feedbackList.txt"))) {
            oos.writeObject(feedbackList);
            System.out.println("Feedbacklist serialized successfully.");
        } catch (IOException e) {
            System.out.println("Error during serialization of Feedbacklist: " + e.getMessage());
        }
    }

    // Deserialize feedbackList from a file
    void deserializeFeedbackList() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("FeedbackAppFiles/feedbackList.txt"))) {
            feedbackList = (List<FeedbackApp>) ois.readObject();
            System.out.println("Feedbacklist deserialized successfully.");
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error during deserialization of Feedbacklist: " + e.getMessage());
        }
    }
}
