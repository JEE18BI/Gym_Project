package javaapplication4;

import java.util.ArrayList;
import java.util.Scanner;
import java.io.*;

public class ClassSchedule {
    private static ArrayList<String> availableClasses;

    public ClassSchedule() {
        availableClasses = new ArrayList<>();
    }

    public ArrayList<String> getAvailableClasses() {
        return availableClasses;
    }

    public void setAvailableClasses(ArrayList<String> availableClasses) {
        this.availableClasses = availableClasses;
    }

    public static void displayAvailableClasses() {
        if (availableClasses.isEmpty()) {
            System.out.println("No classes available.");
        } else {
            System.out.println("Available Classes:");
            for (String className : availableClasses) {
                System.out.println(className);
            }
        }
    }

    public static void addAvailableClass() {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter the name of the class to add:");
        String className = input.nextLine();

        availableClasses.add(className);
        System.out.println("Class '" + className + "' added successfully.");
    }

    public static void deleteAvailableClass() {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter the name of the class to delete:");
        String className = input.nextLine();

        if (availableClasses.contains(className)) {
            availableClasses.remove(className);
            System.out.println("Class '" + className + "' deleted successfully.");
        } else {
            System.out.println("Class '" + className + "' not found.");
        }
    }

    public void serializeClassSchedules() {
            try (PrintWriter writer = new PrintWriter(new FileWriter("/Users/ahmedosama/NetBeansProjects/JavaApplication4/ClassScheduleFiles/availableClasses.txt"))) {
                for (String name : availableClasses) {
                    writer.println(name);
                }
                System.out.println("availableClasses serialized successfully.");
            }catch (IOException e) {
                System.out.println("Error during serialization of availableClasses: " + e.getMessage());
            }
        }
        
        public void deserializeClassSchedules() {
            try (BufferedReader reader = new BufferedReader(new FileReader("/Users/ahmedosama/NetBeansProjects/JavaApplication4/ClassScheduleFiles/availableClasses.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                availableClasses.add(line);
            }
            System.out.println("availableClasses deserialized successfully.");
        } catch (IOException e) {
            System.out.println("Error during deserialization of availableClasses: " + e.getMessage());
        }
        }
}