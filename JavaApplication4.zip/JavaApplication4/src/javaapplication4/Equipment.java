package javaapplication4;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class Equipment {
    private static ArrayList<String> Equipment_Name = new ArrayList<>();
    private static ArrayList<Integer> Equipment_Quantity = new ArrayList<>();

    // Setters
    public void setEquipment_Name(ArrayList<String> Equipment_Name) {
        this.Equipment_Name = Equipment_Name;
    }

    public void setEquipment_Quantity(ArrayList<Integer> Equipment_Quantity) {
        this.Equipment_Quantity = Equipment_Quantity;
    }

    // Getters
    public ArrayList<String> getEquipment_Name() {
        return Equipment_Name;
    }

    public ArrayList<Integer> getEquipment_Quantity() {
        return Equipment_Quantity;
    }

    public void Display_Equipment() {
        System.out.println("Equipments:");
        for (int i = 0; i < getEquipment_Name().size(); i++) {
            String equipment = getEquipment_Name().get(i);
            int quantity = getEquipment_Quantity().get(i);
            System.out.println(equipment + " - Quantity: " + quantity);
        }
    }

    public void Add_Equipment() {
        String name;
        int num;

        Scanner input = new Scanner(System.in);
        try {
            System.out.println("Enter Equipment Name:");
            name = input.nextLine();
            input.nextLine();
            System.out.println("Enter Equipment Quantity:");
            num = input.nextInt();
            // Add the equipment to the list
            getEquipment_Name().add(name);
            getEquipment_Quantity().add(num);

            // Display equipments
            Display_Equipment();
        } catch (Exception e) {
            System.out.println("Error: Invalid input. Please enter valid data.");
            input.nextLine(); // Consume the invalid input
        }
    }

    public void Edit_Quantity() {
        Scanner input = new Scanner(System.in);
        Display_Equipment();
        System.out.println("Enter the equipment you want to modify");
        String EquipmentToEdit = input.nextLine();

        int index = getEquipment_Name().indexOf(EquipmentToEdit);

        if (index != -1) {
            try {
                System.out.println("Editing quantity of " + EquipmentToEdit);
                int newNum = input.nextInt();
                getEquipment_Quantity().set(index, newNum);
                System.out.println("Quantity updated!");
            } catch (Exception e) {
                System.out.println("Error: Invalid input. Please enter valid data.");
                input.nextLine(); // Consume the invalid input
            }

        } else {
            System.out.println("Equipment with name " + EquipmentToEdit + " not found.");
        }
    }

    public void Delete_Equipment() {
        Scanner input = new Scanner(System.in);

        // Display equipments
        Display_Equipment();

        System.out.println("Enter the Equipment to delete:");
        String EquipmentToDelete = input.nextLine();

        boolean found = false;
        for (int i = 0; i < getEquipment_Name().size(); i++) {
            if (getEquipment_Name().get(i).equals(EquipmentToDelete)) {
                found = true;
                System.out.println("Deleting " + getEquipment_Name().get(i));
                getEquipment_Name().remove(i);
                System.out.println("Equipment deleted successfully.");
                break; // Exit the loop once the equipment is deleted
            }
        }

        if (!found) {
            System.out.println("Equipment not found.");
        }
    }

    public void serializeEquipmentArrayLists() {
        try (PrintWriter writer = new PrintWriter(new FileWriter("/Users/ahmedosama/NetBeansProjects/JavaApplication4/EquipmentFiles/Equipment_Quantity.txt"))) {
            for (Integer quantity : getEquipment_Quantity()) {
                writer.println(quantity);
            }
            System.out.println("Equipment_Quantity serialized successfully.");
        } catch (IOException e) {
            System.out.println("Error during serialization of Equipment_Quantity: " + e.getMessage());
        }

        try (PrintWriter writer = new PrintWriter(new FileWriter("/Users/ahmedosama/NetBeansProjects/JavaApplication4/EquipmentFiles/Equipment_Name.txt"))) {
            for (String name : getEquipment_Name()) {
                writer.println(name);
            }
            System.out.println("Equipment_Name serialized successfully.");
        } catch (IOException e) {
            System.out.println("Error during serialization of Equipment_Name: " + e.getMessage());
        }
    }

    public void deserializeEquipmentArrayLists() {
        try (BufferedReader reader = new BufferedReader(new FileReader("/Users/ahmedosama/NetBeansProjects/JavaApplication4/EquipmentFiles/Equipment_Quantity.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                getEquipment_Quantity().add(Integer.parseInt(line));
            }
            System.out.println("Equipment_Quantity deserialized successfully.");
        } catch (IOException | NumberFormatException e) {
            System.out.println("Error during deserialization of Equipment_Quantity: " + e.getMessage());
        }

        try (BufferedReader reader = new BufferedReader(new FileReader("/Users/ahmedosama/NetBeansProjects/JavaApplication4/EquipmentFiles/Equipment_Name.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                getEquipment_Name().add(line);
            }
            System.out.println("Equipment_Name deserialized successfully.");
        } catch (IOException e) {
            System.out.println("Error during deserialization of Equipment_Name: " + e.getMessage());
        }
    }
}
