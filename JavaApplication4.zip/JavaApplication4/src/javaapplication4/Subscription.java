package javaapplication4;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.io.*;

public class Subscription extends javaapplication4.MembershipPlan {

     ArrayList<Integer> SubscribedCustomerID = new ArrayList<>();
  ArrayList<Integer> AssignedCoachID = new ArrayList<>();

     public ArrayList<Integer> getSubscribedCustomerID() {
        return SubscribedCustomerID;
    }

    public void setSubscribedCustomerID(ArrayList<Integer> subscribedCustomerID) {
        this.SubscribedCustomerID = subscribedCustomerID;
    }

    public ArrayList<Integer> getAssignedCoachID() {
        return AssignedCoachID;
    }

    public void setAssignedCoachID(ArrayList<Integer> assignedCoachID) {
        this.AssignedCoachID = assignedCoachID;
    }

    @Override
    public void ChooseMembershipPlan() {
        // Your overridden implementation here
        // You can also call the superclass method using super.ChooseMembershipPlan() if needed
        System.out.println("Specialized subscription plan selection logic for Subscription class.");
        super.ChooseMembershipPlan();  // Calling the superclass method if needed
    }

    public void AddSubscription(Customer customer, String date) {
        getSubscription_Date().add(date);
        Scanner scanner = new Scanner(System.in);
        int payment;

        System.out.print("Enter customer ID: ");
        int customerId = scanner.nextInt();
        int customerIndex = customer.getCustomer_ID().indexOf(customerId);

        if (customerIndex == -1) {
            System.out.println("Customer with ID " + customerId + " not found.");
            return;
        }

        getSubscribedCustomerID().add(customerId);
        getSubscribedCustomerIDcopy().add(customerId);
        System.out.println("Enter coach ID you'd like to subscribe with : ");
        int coach_choice = scanner.nextInt();
        getAssignedCoachID().add(coach_choice);

        ChooseMembershipPlan();
    }

    public void displaySubscriptionHistory() {
        try {
            System.out.println("Enter customer id: ");
            int customerId = scanner.nextInt();

            int customerIndex = getSubscribedCustomerID().indexOf(customerId);
            if (customerIndex == -1) {
                System.out.println("Customer with ID " + customerId + " not found.");
            } else {
                System.out.println("Subscription details for Customer ID " + customerId + ":");
                for (int i = 0; i < getSubscribedCustomerID().size(); i++) {
                    if (getSubscribedCustomerID().get(i) == customerId) {
                        System.out.println("Subscription Date: " + getSubscription_Date().get(i));
                        System.out.println("Subscribed Plan: " + getSubscribedPlan().get(i));
                        System.out.println("Assigned Coach ID: " + getAssignedCoachID().get(i));
                        System.out.println("Number of Months: " + getMonthsNum().get(i));
                        System.out.println("Subscription Cost: " + getSubscription_Cost().get(i));
                        System.out.println("-----------------------");
                    }
                }
            }
        } catch (InputMismatchException e) {
            System.out.println("Invalid input. Please enter a valid number for customer ID.");
        }
    }
        
        public void serializeSubscriptionArrayLists() {
            try (PrintWriter writer = new PrintWriter(new FileWriter("/Users/ahmedosama/NetBeansProjects/JavaApplication4/SubscriptionFiles/SubscribedCustomerID.txt"))) {
            for (Integer id : SubscribedCustomerID) {
                writer.println(id);
            }
            System.out.println("SubscribedCustomerID serialized successfully.");
        } catch (IOException e) {
            System.out.println("Error during serialization of SubscribedCustomerID: " + e.getMessage());
        }
            
            try (PrintWriter writer = new PrintWriter(new FileWriter("/Users/ahmedosama/NetBeansProjects/JavaApplication4/SubscriptionFiles/AssignedCoachID.txt"))) {
            for (Integer id : AssignedCoachID) {
                writer.println(id);
            }
            System.out.println("AssignedCoachID serialized successfully.");
        } catch (IOException e) {
            System.out.println("Error during serialization of AssignedCoachID: " + e.getMessage());
        }
        }
        
        public void deserializeSubscriptionArrayLists() {
            try (BufferedReader reader = new BufferedReader(new FileReader("/Users/ahmedosama/NetBeansProjects/JavaApplication4/SubscriptionFiles/SubscribedCustomerID.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.isEmpty()) {
                    SubscribedCustomerID.add(Integer.parseInt(line));
                }
            }   
            System.out.println("SubscribedCustomerID deserialized successfully.");
        } catch (IOException | NumberFormatException e) {
            System.out.println("Error during deserialization of SubscribedCustomerID: " + e.getMessage());
        }
            
            try (BufferedReader reader = new BufferedReader(new FileReader("/Users/ahmedosama/NetBeansProjects/JavaApplication4/SubscriptionFiles/AssignedCoachID.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.isEmpty()) {
                    AssignedCoachID.add(Integer.parseInt(line));
                }
            }
            System.out.println("AssignedCoachID deserialized successfully.");
        } catch (IOException | NumberFormatException e) {
            System.out.println("Error during deserialization of AssignedCoachID: " + e.getMessage());
        }
        }
}