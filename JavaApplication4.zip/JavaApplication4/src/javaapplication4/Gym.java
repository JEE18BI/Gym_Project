/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication4;

/**
 *
 * @author ahmedosama
 */
import java.util.Scanner;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
public class Gym {
    private javaapplication4.Customer customer;
    Subscription subscription = new Subscription();

    // Constructor to initialize the Customer instance
    public Gym(javaapplication4.Customer customer) {
        this.customer = customer;
    }

    public void displayCustomersByRegistrationDate() {
        boolean found = false;
        System.out.println("Enter target's date (DD-MM-YYYY):");
        Scanner input = new Scanner(System.in);
        String targetDate = input.nextLine();

        System.out.println("Customers registered on " + targetDate + ":");

        for (int i = 0; i < customer.Customer_RegistrationDate.size(); i++) {
            if (customer.Customer_RegistrationDate.get(i).equals(targetDate)) {
                System.out.println("Customer ID: " + javaapplication4.Customer.Customer_ID.get(i));
                System.out.println("Name: " + javaapplication4.Customer.Customer_Name.get(i));
                System.out.println("Gender: " + customer.Customer_Gender.get(i));
                System.out.println("Age: " + customer.getCustomer_Age().get(i));
                System.out.println("Address: " + customer.getCustomer_Address().get(i));
                System.out.println("Email: " + customer.Customer_Email.get(i));
                System.out.println("Assigned Coach ID: " + customer.Customer_AssignedCoach.get(i));
                System.out.println("-------------------------");
                found = true;
            }
        }

        if (!found) {
            System.out.println("No customers found for the specified date.");
        }
    }

    public void DisplayGymIncomeInAMonth(Subscription subscription) {
        int totalIncome = 0;

        // Input a Month
        System.out.println("Enter target month (MM):");
        Scanner input = new Scanner(System.in);
        int targetMonth;
        try {
            targetMonth = Integer.parseInt(input.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Invalid input for month. Please enter a valid month (MM).");
            return;
        }

        // Search through all Subscription_Date arraylist using a for loop
        for (int i = 0; i < subscription.Subscription_Date.size(); i++) {
            try {
                // Parse the date string to a Date object
                SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
                Date subscriptionDate = dateFormat.parse(subscription.Subscription_Date.get(i));

                // Create a Calendar instance and set it to the subscription date
                Calendar cal = Calendar.getInstance();
                cal.setTime(subscriptionDate);

                // Check if the month is the same as the target month
                if (cal.get(Calendar.MONTH) + 1 == targetMonth) {
                    // Add the value of Subscription_Cost with the same index of Subscription_Date to totalIncome
                    totalIncome += subscription.Subscription_Cost.get(i);
                }
            } catch (Exception e) {
                System.out.println("Error parsing date: " + e.getMessage());
            }
        }

        // Return the totalIncome
        System.out.println("Total income for the month " + targetMonth + ": $" + totalIncome);
    }

}
