package javaapplication4;

import java.text.ParseException;
import java.util.Scanner;
import java.time.format.DateTimeFormatter;
import java.time.LocalDate;
public class Main {
    public static void main(String[] args) throws ParseException {
        MembershipPlan M = new MembershipPlan();
        Subscription subscription = new Subscription();
        Customer customer = new Customer();
        Coach coach = new Coach();
        Equipment equipment = new Equipment();
        InBody inBody = new InBody();
        Gym gym = new Gym(customer);
        ClassSchedule classes = new ClassSchedule();
        FeedbackApp feedbackApp = new FeedbackApp();
        
        customer.deserializeCustomerArrayLists();
        subscription.deserializeSubscriptionArrayLists();
        coach.deserializeCoachArrayLists();
        subscription.deserializeMembershipPlanArrayLists();
        inBody.deserializeInBodyArrayLists();
        feedbackApp.deserializeFeedbackList();   
        classes.deserializeClassSchedules();
        equipment.deserializeEquipmentArrayLists();


            try {
                System.out.println("====================================");
                System.out.println("            GYM MANAGEMENT           ");
                System.out.println("====================================");
                Scanner input = new Scanner(System.in);
                String todayDate = getValidDateInput();

                System.out.println("Hello, choose an option:");
                System.out.println("1. Customer Management");
                System.out.println("2. Coach Management");
                System.out.println("3. Gym Management");
                System.out.println("4. Feedback");

                int ans = input.nextInt();

                switch (ans) {
                    case 1:
                        boolean check1 = false;

                        while (!check1) {
                            check1 = customer.customerlogin();

                            if (check1) {
                                handleCustomerActions(todayDate, customer, inBody, subscription, M, coach);
                            }
                        }

                        break;
                    case 2:
                        boolean check2 = false;

                        while (!check2) {
                            check2 = coach.coachlogin();

                            if (check2) {
                                handleCoachActions(customer, coach, inBody);
                            }
                        }
                        break;
                    case 3:
                        boolean loggedIn = false;
                        Scanner input2 = new Scanner(System.in);
                        String user;
                        String pass;

                        do {
                            System.out.println("Enter username: ");
                            // consume any remaining newline characters

                            user = input2.nextLine();


                            System.out.println("Enter password: ");
                           pass = input2.nextLine();

                            if (user.equals("admin") && pass.equals("admin")) {
                                handleGymActions(todayDate, customer, coach, gym, equipment, subscription);
                                loggedIn = true; // Set the flag to exit the loop
                            } else {
                                System.out.println("Wrong entry. Try again.");
                            }
                        } while (!loggedIn);

                      break;




                    case 4:
                        handleFeedbackActions(feedbackApp);
                        break;

                    case 0: // Add an option to exit
                        System.out.println("Exiting program. Goodbye!");
                        System.exit(0);
                    default:
                        System.out.println("Invalid option. Please choose again.");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
            
        System.out.println("====================================");
        customer.serializeCustomerArrayLists();
        subscription.serializeSubscriptionArrayLists();
        coach.serializeCoachArrayLists();
        subscription.serializeMembershipPlanArrayLists();
        inBody.serializeInBodyArrayLists();
        feedbackApp.serializeFeedbackList();
        classes.serializeClassSchedules();
        equipment.serializeEquipmentArrayLists();
        
        }
    
    private static String getValidDateInput() {
        Scanner input = new Scanner(System.in);
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");

        while (true) {
            try {
                System.out.println("Enter today's date (DD-MM-YYYY):");
                String inputDate = input.nextLine();

                // Parse the input date string to LocalDate
                LocalDate.parse(inputDate, dateFormatter);

                return inputDate; // Return the date if parsing is successful
            } catch (Exception e) {
                System.out.println("Invalid date format. Please enter the date in DD-MM-YYYY format.");
            }
        }
    }

    private static void handleCustomerActions(String todayDate, Customer customer, InBody inBody,
                                              Subscription subscription, MembershipPlan membershipPlan, Coach coach) throws ParseException {
        Scanner input = new Scanner(System.in);
        System.out.println("====================================");
        System.out.println("        CUSTOMER MANAGEMENT         ");
        System.out.println("====================================");
        System.out.println("1. Show Subscription History");
        System.out.println("2. Do InBody");
        System.out.println("3. Display InBody Details");
        System.out.println("4. Display Weight Goal");
        System.out.println("5. Display Coach Details");
        System.out.println("6. Display Membership Plan Details");
        System.out.println("7. Subscribe");
        System.out.println("8. Show Available Classes");


        int ans2 = input.nextInt();

        switch (ans2) {
            case 1:
                subscription.displaySubscriptionHistory();
                break;
            case 2:
                inBody.DoInBody(customer, todayDate);
                break;
            case 3:
                inBody.displayInBodyDetails(customer);
                break;
            case 4:
                inBody.displayWeightGoal(customer);
                break;
            case 5:
                customer.displayAssignedCoachDetails(coach);
                break;
            case 6:
                subscription.DisplayMembershipPlanDetails();
                break;
            case 7:
                subscription.AddSubscription(customer, todayDate);
                break;
            case 8:
                ClassSchedule.displayAvailableClasses();
                break;
            default:
                System.out.println("Invalid option. Please choose again.");
        }
    }

    private static void handleCoachActions(Customer customer, Coach coach, InBody inBody) {
        Scanner input = new Scanner(System.in);
        System.out.println("====================================");
        System.out.println("          COACH MANAGEMENT          ");
        System.out.println("====================================");
        System.out.println("1. Display All Customers");
        System.out.println("2. Get Customer Details");
        System.out.println("3. Get Customer InBody");
        System.out.println("4. Show Male/Female Customers");


        int ans2 = input.nextInt();
        switch (ans2) {
            case 1:
                System.out.println("Enter Coach ID to display customers: ");
                int coachId = new Scanner(System.in).nextInt();
                coach.DisplayCustomersForCoach(coachId, customer);
                break;
            case 2:
                coach.getCustomerDetailsByCoachId(customer);
                break;
            case 3:
                inBody.displayInBodyDetails(customer);
                break;
            case 4:
                coach.displayCustomersByGender(customer);
                break;
            default:
                System.out.println("Invalid option. Please choose again.");
        }
    }



    private static void handleGymActions(String todayDate, Customer customer, Coach coach, Gym gym, Equipment equipment,
                                         Subscription subscription) {
        Scanner input = new Scanner(System.in);
        System.out.println("====================================");
        System.out.println("            GYM MANAGEMENT           ");
        System.out.println("====================================");
        System.out.println("1. Add");
        System.out.println("2. Edit");
        System.out.println("3. Delete");
        System.out.println("4. Display Equipment");
        System.out.println("5. Display Customers on a Certain Day");
        System.out.println("6. Display Gym Income in a Month");
        System.out.println("7. Order Coaches");
        System.out.println("8. Show Available Classes");
        System.out.println("9. Add Classes");
        System.out.println("10. delete Classes");

        int ans2 = input.nextInt();
        switch (ans2) {
            case 1:
                System.out.println("1. Customer");
                System.out.println("2. Coach");
                System.out.println("3. Equipment");
                int ans3 = input.nextInt();

                switch (ans3) {
                    case 1:
                        customer.Add_Customer(todayDate);
                        break;
                    case 2:
                        Coach.Add_Coach();
                        break;
                    case 3:
                        equipment.Add_Equipment();
                        break;
                }
                break;
            case 2:
                System.out.println("1. Customer");
                System.out.println("2. Coach");
                System.out.println("3. Equipment Quantity");
                int ans4 = input.nextInt();

                switch (ans4) {
                    case 1:
                        customer.Edit_Customer();
                        break;
                    case 2:
                        coach.Edit_Coach();
                        break;
                    case 3:
                        equipment.Edit_Quantity();
                        break;
                }
                break;
            case 3:
                System.out.println("1. Customer");
                System.out.println("2. Coach");
                System.out.println("3. Equipment");
                int ans5 = input.nextInt();

                switch (ans5) {
                    case 1:
                        customer.Delete_Customer();
                        break;
                    case 2:
                        coach.Delete_Coach();
                        break;
                    case 3:
                        equipment.Delete_Equipment();
                        break;
                }
                break;
            case 4:
                equipment.Display_Equipment();
                break;
            case 5:
                gym.displayCustomersByRegistrationDate();
                break;
            case 6:
                gym.DisplayGymIncomeInAMonth(subscription);
                break;
            case 7:
                coach.orderCoachesByCustomerCount(customer);
                break;
            case 8:
                ClassSchedule.displayAvailableClasses();                
                break;
            case 9:
                ClassSchedule.addAvailableClass();                
                break;
            case 10:
                ClassSchedule.deleteAvailableClass();
                break;
            default:
                System.out.println("Invalid option. Please choose again.");
        }
    }


    private static void handleFeedbackActions(FeedbackApp feedbackApp) {
        Scanner input = new Scanner(System.in);
        System.out.println("====================================");
        System.out.println("             FEEDBACK                ");
        System.out.println("====================================");
        System.out.println("1. Add Feedback");
        System.out.println("2. Display Feedback");


        int ans2 = input.nextInt();
        handleFeedbackSubActions(ans2, feedbackApp);
    }

    private static void handleFeedbackSubActions(int option, FeedbackApp feedbackApp) {
        switch (option) {
            case 1:
                // Get feedback from the user
                Scanner input = new Scanner(System.in);
                System.out.print("Enter your User ID: ");
                int userId = input.nextInt();
                input.nextLine(); // Consume the newline character
                System.out.print("Enter your feedback: ");
                String comment = input.nextLine();
                feedbackApp.addFeedback(userId, comment);
                break;
            case 2:
                // Display all feedback
                feedbackApp.displayFeedback();
                break;


            default:
                System.out.println("Invalid option. Please choose again.");
        }
    }
}
