
package javaapplication4;


import java.io.*;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class Coach
{

    // Add similar lines for other ArrayLists

    static ArrayList<Integer> Coach_ID = new ArrayList<>();
    private static ArrayList<String> Coach_Password = new ArrayList<>();
    static ArrayList<String> Coach_Name = new ArrayList<>();
    ArrayList<String> Coach_Gender = new ArrayList<>();
    private static ArrayList<String> Coach_Email = new ArrayList<>();
    private static ArrayList<String> Coach_Address = new ArrayList<>();
    static ArrayList<Integer> Coach_PhoneNumber = new ArrayList<>();
    ArrayList<Integer> Coach_WorkingHours = new ArrayList<>();
    ArrayList<Integer> availableCoaches = new ArrayList<>();  // Declare the list

    Scanner input = new Scanner(System.in);

    public static ArrayList<Integer> getCoach_ID() {
        return Coach_ID;
    }

    public void setCoachID(ArrayList<Integer> Coach_ID) {
        this.Coach_ID = Coach_ID;
    }

    public ArrayList<String> getCoach_Password() {
        return Coach_Password;
    }

    public void setCoachPassword(ArrayList<String> Coach_Password) {
        this.Coach_Password = Coach_Password;
    }

    public static ArrayList<String> getCoach_Name() {
        return Coach_Name;
    }

    public void setCoachName(ArrayList<String> Coach_Name) {
        this.Coach_Name = Coach_Name;
    }

    public ArrayList<String> getCoach_Gender() {
        return Coach_Gender;
    }

    public void setCoachGender(ArrayList<String> Coach_Gender) {
        this.Coach_Gender = Coach_Gender;
    }

    public static ArrayList<String> getCoach_Email() {
        return Coach_Email;
    }

    public void setCoachEmail(ArrayList<String> Coach_Email) {
        this.Coach_Email = Coach_Email;
    }

    public ArrayList<String> getCoach_Address() {
        return Coach_Address;
    }

    public void setCoachAddress(ArrayList<String> Coach_Address) {
        this.Coach_Address = Coach_Address;
    }

    public ArrayList<Integer> getCoach_PhoneNumber() {
        return Coach_PhoneNumber;
    }

    public void setCoachPhoneNumber(ArrayList<Integer> Coach_PhoneNumber) {
        this.Coach_PhoneNumber = Coach_PhoneNumber;
    }

    public ArrayList<Integer> getCoach_WorkingHours() {
        return Coach_WorkingHours;
    }

    public void setCoachWorkingHours(ArrayList<Integer> Coach_WorkingHours) {
        this.Coach_WorkingHours = Coach_WorkingHours;
    }

    public ArrayList<Integer> getAvailableCoaches() {
        return availableCoaches;
    }

    public void setAvailableCoaches(ArrayList<Integer> availableCoaches) {
        this.availableCoaches = availableCoaches;
    }

    public static void Add_Coach() {
    Coach coach = new Coach(); // Create an instance of Coach

    int id;
    String name;
    String address;
    int phone;
    String email;

    Scanner input = new Scanner(System.in);
    boolean validId = false;

    while (!validId) {
        try {
            System.out.println("Enter Coach ID:");
            id = input.nextInt();

            // Check if Coach ID already exists
            if (coach.getCoach_ID().contains(id)) {
                System.out.println("Coach with ID " + id + " already exists. Please enter a different ID.");
            } else {
                input.nextLine();  // Consume the newline character
                coach.getCoach_ID().add(id);
                validId = true;  // Set the flag to exit the loop
            }
        } catch (InputMismatchException e) {
            System.out.println("Invalid input. Please enter a valid integer for Coach ID.");
            input.nextLine();  // Consume the invalid input
        }
    }

    System.out.println("Enter coach password:");
    String pas = input.nextLine();
    coach.getCoach_Password().add(pas);

    boolean validName = false;
    while (!validName) {
        try {
            System.out.println("Enter Coach name:");
            name = input.nextLine();
            if (!name.trim().isEmpty() && !name.matches(".*\\d.*")) {
                // Check if the name is not empty and does not contain any digits
                coach.getCoach_Name().add(name);
                validName = true;
            } else {
                throw new IllegalArgumentException("Invalid name. Please enter a non-empty name without numbers.");
            }
        } catch (NoSuchElementException | IllegalArgumentException e) {
            System.out.println(e.getMessage());
            // Consume the invalid input
        }
    }

    System.out.println("Enter Coach address:");
    address = input.nextLine();
    coach.getCoach_Address().add(address);

    System.out.println("Enter Coach email:");
    email = input.nextLine();
    coach.getCoach_Email().add(email);

    boolean validPhone = false;
    while (!validPhone) {
        try {
            System.out.println("Enter Coach phone number:");
            phone = input.nextInt();
            coach.getCoach_PhoneNumber().add(phone);
            validPhone = true;
        } catch (InputMismatchException e) {
            System.out.println("Invalid input. Please enter a valid number for phone number.");
            input.nextLine(); // Consume the invalid input
        }
    }
}



    public void Edit_Coach() {
        Scanner input = new Scanner(System.in);

        System.out.println("Enter the coach ID to edit:");
        int idToEdit = input.nextInt();

        int index = Coach_ID.indexOf(idToEdit);

        if (index != -1) {
            System.out.println("Editing coach with ID: " + idToEdit);

            // You can choose which information to edit
            System.out.println("1. Edit Name");
            System.out.println("2. Edit Address");
            System.out.println("3. Edit Email");
            System.out.println("4. Edit Phone number");

            int choice = input.nextInt();
            input.nextLine();  // Consume the newline character

            switch (choice) {
                case 1:
                    System.out.println("Enter new name:");
                    String newName = input.nextLine();
                    Coach_Name.set(index, newName);
                    break;
                case 2:
                    System.out.println("Enter new address:");
                    String newAddress = input.nextLine();
                    Coach_Address.set(index, newAddress);
                    break;
                case 3:
                    System.out.println("Enter new email:");
                    String newEmail = input.nextLine();
                    Coach_Email.set(index, newEmail);
                    break;
                case 4:
                    System.out.println("Enter new phone number:");
                    int newPhone = input.nextInt();
                    Coach_PhoneNumber.set(index, newPhone);
                    break;
                default:
                    System.out.println("Invalid choice.");
            }

            System.out.println("Coach information updated:");
            System.out.println("ID: " + Coach_ID.get(index));
            System.out.println("Name: " + Coach_Name.get(index));
            System.out.println("Address: " + Coach_Address.get(index));
            System.out.println("Email: " + Coach_Email.get(index));
            System.out.println("Phone: " + Coach_PhoneNumber.get(index));
        } else {
            System.out.println("Coach with ID " + idToEdit + " not found.");
        }
    }


    public void Delete_Coach() {
        Scanner input = new Scanner(System.in);

        System.out.println("Enter the coach ID to delete:");
        int idToDelete = input.nextInt();

        int index = Coach_ID.indexOf(idToDelete);

        if (index != -1) {
            System.out.println("Deleting coach with ID: " + idToDelete);

            // Display the coach information before deletion
            System.out.println("Coach information to be deleted:");
            System.out.println("ID: " + Coach_ID.get(index));
            System.out.println("Name: " + Coach_Name.get(index));
            System.out.println("Address: " + Coach_Address.get(index));
            System.out.println("Email: " + Coach_Email.get(index));
            System.out.println("Phone Number: " + Coach_PhoneNumber.get(index));
            // Remove the coach from the lists
            Coach_ID.remove(index);
            Coach_Name.remove(index);
            Coach_Address.remove(index);
            Coach_Email.remove(index);
            Coach_PhoneNumber.remove(index);

            System.out.println("Coach deleted successfully.");
        } else {
            System.out.println("Coach with ID " + idToDelete + " not found.");
        }
    }


    public void DisplayCustomersForCoach(int coachId, javaapplication4.Customer customer) {
        System.out.println("Customers assigned to Coach ID " + coachId + ":");
        for (int i = 0; i < customer.getCustomer_ID().size(); i++) {

            if (customer.getCustomer_AssignedCoach().get(i) == coachId) {
                System.out.println("Customer ID: " + customer.getCustomer_ID().get(i) + ", Name: " + customer.getCustomer_Name().get(i));
            }
        }
    }

    public void getCustomerDetailsByCoachId(javaapplication4.Customer customer) {
        Scanner input = new Scanner(System.in);

        // Prompt for Coach ID
        System.out.println("Enter Coach ID:");
        int coachId = input.nextInt();

        // Check if the coach exists
        if (Coach_ID.contains(coachId)) {
            // Prompt for Customer Name
            System.out.println("Enter Customer Name:");
            input.nextLine();  // Consume the newline character
            String customerName = input.nextLine();

            // Find the customer index based on the name
            int customerIndex = customer.getCustomer_Name().indexOf(customerName);

            if (customerIndex != -1 && customer.getCustomer_AssignedCoach().get(customerIndex) == coachId) {
                // Display Customer Details
                System.out.println("Customer Details:");
                System.out.println("ID: " + customer.getCustomer_ID().get(customerIndex));
                System.out.println("Name: " + customerName);
                System.out.println("Address: " + customer.getAddress().get(customerIndex));
                System.out.println("Email: " + customer.getCustomer_Email().get(customerIndex));
                System.out.println("Age: " + customer.getCustomer_Age().get(customerIndex));
                System.out.println("Gender: " + customer.getCustomer_Gender().get(customerIndex));
                System.out.println("Assigned Coach ID: " + coachId);
            } else {
                System.out.println("Customer not found or not assigned to the specified coach.");
            }
        } else {
            System.out.println("Coach with ID " + coachId + " not found.");
        }
    }

    public void displayCustomersByGender(javaapplication4.Customer customer) {

        System.out.println("Enter Coach ID:");
        int coachId = input.nextInt();
        input.nextLine();

        System.out.println("Choose gender: (1-Male  2-Female)");
        int genderChoice = input.nextInt();
        input.nextLine();

        String gender = (genderChoice == 1) ? "Male" : "Female";

        System.out.println("List of " + gender + " customers assigned to Coach ID " + coachId + ":");

        for (int i = 0; i < customer.getCustomer_ID().size(); i++) {
            if (customer.getCustomer_AssignedCoach().get(i) == coachId && customer.getCustomer_Gender().get(i).equalsIgnoreCase(gender)) {
                System.out.println("Customer ID: " + customer.getCustomer_ID().get(i) + ", Name: " + customer.getCustomer_Name().get(i));
            }
        }
    }

    //////
    public void orderCoachesByCustomerCount(javaapplication4.Customer customer) {
        ArrayList<Integer> sortedCoachIds = new ArrayList<>(Coach_ID);

        // Sort the coach IDs based on customer count in descending order
        sortedCoachIds.sort((coachId1, coachId2) ->
                Integer.compare(getCustomerCountForCoach(coachId2, customer),
                        getCustomerCountForCoach(coachId1, customer)));

        // Display the ordered coaches
        System.out.println("Coaches ordered by the number of customers they train:");
        for (int coachId : sortedCoachIds) {
            int coachIndex = Coach_ID.indexOf(coachId);
            System.out.println("Coach ID: " + coachId +
                    ", Coach Name: " + Coach_Name.get(coachIndex) +
                    ", Customer Count: " + getCustomerCountForCoach(coachId, customer));
        }
    }



    // Helper function to get the number of customers assigned to a coach
    public int getCustomerCountForCoach(int coachId, javaapplication4.Customer customer) {
        int customerCount = 0;
        for (int assignedCoachId : customer.getCustomer_AssignedCoach()) {
            if (assignedCoachId == coachId) {
                customerCount++;
            }
        }
        return customerCount;
    }

    public void serializeCoachArrayLists() {
        try (PrintWriter writer = new PrintWriter(new FileWriter("/Users/ahmedosama/NetBeansProjects/JavaApplication4/CoachFiles/Coach_ID.txt"))) {
            for (Integer id : Coach_ID) {
                writer.println(id);
            }
            System.out.println("Coach_ID serialized successfully.");
        } catch (IOException e) {
            System.out.println("Error during serialization of Coach_ID: " + e.getMessage());
        }

        try (PrintWriter writer = new PrintWriter(new FileWriter("/Users/ahmedosama/NetBeansProjects/JavaApplication4/CoachFiles/Coach_Password.txt"))) {
            for (String pass : Coach_Password) {
                writer.println(pass);
            }
            System.out.println("Coach_Password serialized successfully.");
        } catch (IOException e) {
            System.out.println("Error during serialization of Coach_Password: " + e.getMessage());
        }

        try (PrintWriter writer = new PrintWriter(new FileWriter("/Users/ahmedosama/NetBeansProjects/JavaApplication4/CoachFiles/Coach_PhoneNumber.txt"))) {
            for (Integer num : Coach_PhoneNumber) {
                writer.println(num);
            }
            System.out.println("Coach_PhoneNumber serialized successfully.");
        } catch (IOException e) {
            System.out.println("Error during serialization of Coach_PhoneNumber: " + e.getMessage());
        }

        try (PrintWriter writer = new PrintWriter(new FileWriter("/Users/ahmedosama/NetBeansProjects/JavaApplication4/CoachFiles/Coach_Name.txt"))) {
            for (String name : Coach_Name) {
                writer.println(name);
            }
            System.out.println("Coach_Name serialized successfully.");
        } catch (IOException e) {
            System.out.println("Error during serialization of Coach_Name: " + e.getMessage());
        }

        try (PrintWriter writer = new PrintWriter(new FileWriter("/Users/ahmedosama/NetBeansProjects/JavaApplication4/CoachFiles/Coach_Email.txt"))) {
            for (String email : Coach_Email) {
                writer.println(email);
            }
            System.out.println("Coach_Email serialized successfully.");
        } catch (IOException e) {
            System.out.println("Error during serialization of Coach_Email: " + e.getMessage());
        }

        try (PrintWriter writer = new PrintWriter(new FileWriter("/Users/ahmedosama/NetBeansProjects/JavaApplication4/CoachFiles/Coach_Address.txt"))) {
            for (String address : Coach_Address) {
                writer.println(address);
            }
            System.out.println("Coach_Address serialized successfully.");
        } catch (IOException e) {
            System.out.println("Error during serialization of Coach_Address: " + e.getMessage());
        }
    }

    public void deserializeCoachArrayLists() {
        try (BufferedReader reader = new BufferedReader(new FileReader("/Users/ahmedosama/NetBeansProjects/JavaApplication4/CoachFiles/Coach_ID.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.isEmpty()) {
                    Coach_ID.add(Integer.parseInt(line));
                }
            }
            System.out.println("Coach_ID deserialized successfully.");
        } catch (IOException | NumberFormatException e) {
            System.out.println("Error during deserialization of Coach_ID: " + e.getMessage());
        }

        try (BufferedReader reader = new BufferedReader(new FileReader("/Users/ahmedosama/NetBeansProjects/JavaApplication4/CoachFiles/Coach_PhoneNumber.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.isEmpty()) {
                    Coach_PhoneNumber.add(Integer.parseInt(line));
                }
            }
            System.out.println("Coach_PhoneNumber deserialized successfully.");
        } catch (IOException | NumberFormatException e) {
            System.out.println("Error during deserialization of Coach_PhoneNumber: " + e.getMessage());
        }

        try (BufferedReader reader = new BufferedReader(new FileReader("/Users/ahmedosama/NetBeansProjects/JavaApplication4/CoachFiles/Coach_Name.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                Coach_Name.add(line);
            }
            System.out.println("Coach_Name deserialized successfully.");
        } catch (IOException e) {
            System.out.println("Error during deserialization of Coach_Name: " + e.getMessage());
        }

        try (BufferedReader reader = new BufferedReader(new FileReader("/Users/ahmedosama/NetBeansProjects/JavaApplication4/CoachFiles/Coach_Password.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                Coach_Password.add(line);
            }
            System.out.println("Coach_Password deserialized successfully.");
        } catch (IOException e) {
            System.out.println("Error during deserialization of Coach_Password: " + e.getMessage());
        }

        try (BufferedReader reader = new BufferedReader(new FileReader("/Users/ahmedosama/NetBeansProjects/JavaApplication4/CoachFiles/Coach_Email.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                Coach_Email.add(line);
            }
            System.out.println("Coach_Email deserialized successfully.");
        } catch (IOException e) {
            System.out.println("Error during deserialization of Coach_Email: " + e.getMessage());
        }

        try (BufferedReader reader = new BufferedReader(new FileReader("/Users/ahmedosama/NetBeansProjects/JavaApplication4/CoachFiles/Coach_Address.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                Coach_Address.add(line);
            }
            System.out.println("Coach_Address deserialized successfully.");
        } catch (IOException e) {
            System.out.println("Error during deserialization of Coach_Address: " + e.getMessage());
        }

    }

    public boolean coachlogin() {
        Scanner input = new Scanner(System.in);

        System.out.println("Enter Coach ID:");
        int customerId = input.nextInt();
        input.nextLine();  // Consume the newline character

        System.out.println("Enter Password:");
        String password = input.nextLine();

        // Check if the provided ID and password match
        int index = Coach_ID.indexOf(customerId);
        if (index != -1 && Coach_Password.get(index).equals(password)) {
            System.out.println("Login successful. Welcome, " + Coach_Name.get(index) + "!");
            return true;
        } else {
            System.out.println("Invalid Coach ID or Password. Login failed.");
            return false;
        }
    }
}