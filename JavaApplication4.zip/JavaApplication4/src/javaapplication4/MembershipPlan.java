package javaapplication4;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.io.*;

public class MembershipPlan {

    Scanner scanner = new Scanner(System.in);
    ArrayList<Integer> SubscribedPlan = new ArrayList<>();
    ArrayList<Integer> MonthsNum = new ArrayList<>();
    ArrayList<Integer> Subscription_Cost = new ArrayList<>();
    ArrayList<String> Subscription_Date = new ArrayList<>();
    ArrayList<Integer> SubscribedCustomerIDcopy = new ArrayList<>();

    public ArrayList<Integer> getSubscribedPlan() {
        return SubscribedPlan;
    }

    public void setSubscribedPlan(ArrayList<Integer> subscribedPlan) {
        this.SubscribedPlan = subscribedPlan;
    }

    public ArrayList<Integer> getMonthsNum() {
        return MonthsNum;
    }

    public void setMonthsNum(ArrayList<Integer> monthsNum) {
        this.MonthsNum = monthsNum;
    }

    public ArrayList<Integer> getSubscription_Cost() {
        return Subscription_Cost;
    }

    public void setSubscription_Cost(ArrayList<Integer> subscription_Cost) {
        this.Subscription_Cost = subscription_Cost;
    }

    public ArrayList<String> getSubscription_Date() {
        return Subscription_Date;
    }

    public void setSubscription_Date(ArrayList<String> subscription_Date) {
        this.Subscription_Date = subscription_Date;
    }

    public ArrayList<Integer> getSubscribedCustomerIDcopy() {
        return SubscribedCustomerIDcopy;
    }

    public void setSubscribedCustomerIDcopy(ArrayList<Integer> subscribedCustomerIDcopy) {
        this.SubscribedCustomerIDcopy = subscribedCustomerIDcopy;
    }

    public void ChooseMembershipPlan() {
        try {
            int payment = 0;
            System.out.println("Our plans:");
            System.out.println("1- 3 days per week ------> 800 per month");
            System.out.println("2- 6 days per week ------> 1500 per month");

            System.out.println("Please choose your plan: ");
            int plan_choice = scanner.nextInt();
            getSubscribedPlan().add(plan_choice);

            System.out.println("How many months do you want to subscribe? : ");
            int num = scanner.nextInt();
            getMonthsNum().add(num);

            if (plan_choice == 1) {
                if (num >= 3) {
                    payment = (int) (800 * num * 0.8);
                    getSubscription_Cost().add(payment);
                } else {
                    payment = 800 * num;
                    getSubscription_Cost().add(payment);
                }
            } else if (plan_choice == 2) {
                if (num >= 3) {
                    payment = (int) (1500 * num * 0.8);
                    getSubscription_Cost().add(payment);
                } else {
                    payment = 1500 * num;
                    getSubscription_Cost().add(payment);
                }
            }
            System.out.println("Required fees to pay: " + payment);
        } catch (InputMismatchException e) {
            System.out.println("Invalid input. Please enter a valid number.");
            scanner.nextLine(); // Consume the invalid input
        }
    }

    public void DisplayMembershipPlanDetails() {
        try {
            System.out.println("Enter customer id: ");
            int customerId = scanner.nextInt();

            int customerIndex = getSubscribedCustomerIDcopy().indexOf(customerId);
            if (customerIndex == -1) {
                System.out.println("Customer with ID " + customerId + " not found.");
            } else {
                String date = null;
                int plan = 0, num = 0, cost = 0;

                System.out.println("Subscription details for Customer ID " + customerId + ":");
                for (int i = 0; i < getSubscribedCustomerIDcopy().size(); i++) {
                    if (getSubscribedCustomerIDcopy().get(i) == customerId) {
                        date = getSubscription_Date().get(i);
                        plan = getSubscribedPlan().get(i);
                        num = getMonthsNum().get(i);
                        cost = getSubscription_Cost().get(i);
                    }
                }

                System.out.println("Subscription Date: " + date);
                System.out.println("Subscribed Plan: " + plan);
                System.out.println("Number of Months: " + num);
                System.out.println("Subscription Cost: " + cost);
            }
        } catch (InputMismatchException e) {
            System.out.println("Invalid input. Please enter a valid number for customer ID.");
            scanner.nextLine(); // Consume the invalid input
        }
    }
    
    public void serializeMembershipPlanArrayLists() {
        try (PrintWriter writer = new PrintWriter(new FileWriter("/Users/ahmedosama/NetBeansProjects/JavaApplication4/MembershipPlanrFiles/SubscribedPlan.txt"))) {
            for (Integer plan : SubscribedPlan) {
                writer.println(plan);
            }
            System.out.println("SubscribedPlan serialized successfully.");
        } catch (IOException e) {
            System.out.println("Error during serialization of SubscribedPlan: " + e.getMessage());
        }
        
        try (PrintWriter writer = new PrintWriter(new FileWriter("/Users/ahmedosama/NetBeansProjects/JavaApplication4/MembershipPlanrFiles/MonthsNum.txt"))) {
            for (Integer num : MonthsNum) {
                writer.println(num);
            }
            System.out.println("MonthsNum serialized successfully.");
        } catch (IOException e) {
            System.out.println("Error during serialization of MonthsNum: " + e.getMessage());
        }
        
        try (PrintWriter writer = new PrintWriter(new FileWriter("/Users/ahmedosama/NetBeansProjects/JavaApplication4/MembershipPlanrFiles/Subscription_Cost.txt"))) {
            for (Integer cost : Subscription_Cost) {
                writer.println(cost);
            }
            System.out.println("Subscription_Cost serialized successfully.");
        } catch (IOException e) {
            System.out.println("Error during serialization of Subscription_Cost: " + e.getMessage());
        }
        
        try (PrintWriter writer = new PrintWriter(new FileWriter("/Users/ahmedosama/NetBeansProjects/JavaApplication4/MembershipPlanrFiles/SubscribedCustomerIDcopy.txt"))) {
            for (Integer id : SubscribedCustomerIDcopy) {
                writer.println(id);
            }
            System.out.println("SubscribedCustomerIDcopy serialized successfully.");
        } catch (IOException e) {
            System.out.println("Error during serialization of SubscribedCustomerIDcopy: " + e.getMessage());
        }
        
        try (PrintWriter writer = new PrintWriter(new FileWriter("/Users/ahmedosama/NetBeansProjects/JavaApplication4/MembershipPlanrFiles/Subscription_Date.txt"))) {
            for (String date : Subscription_Date) {
                writer.println(date);
            }
            System.out.println("Subscription_Date serialized successfully.");
        } catch (IOException e) {
            System.out.println("Error during serialization of Subscription_Date: " + e.getMessage());
        }
    }
    
    public void deserializeMembershipPlanArrayLists() {
        try (BufferedReader reader = new BufferedReader(new FileReader("/Users/ahmedosama/NetBeansProjects/JavaApplication4/MembershipPlanrFiles/SubscribedPlan.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.isEmpty()) {
                SubscribedPlan.add(Integer.parseInt(line));
                }
            }
            System.out.println("SubscribedPlan deserialized successfully.");
        } catch (IOException | NumberFormatException e) {
            System.out.println("Error during deserialization of SubscribedPlan: " + e.getMessage());
        }
        
        try (BufferedReader reader = new BufferedReader(new FileReader("/Users/ahmedosama/NetBeansProjects/JavaApplication4/MembershipPlanrFiles/MonthsNum.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.isEmpty()) {
                MonthsNum.add(Integer.parseInt(line));
                }
            }
            System.out.println("MonthsNum deserialized successfully.");
        } catch (IOException | NumberFormatException e) {
            System.out.println("Error during deserialization of MonthsNum: " + e.getMessage());
        }
        
        try (BufferedReader reader = new BufferedReader(new FileReader("/Users/ahmedosama/NetBeansProjects/JavaApplication4/MembershipPlanrFiles/Subscription_Cost.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.isEmpty()) {
                Subscription_Cost.add(Integer.parseInt(line));
                }
            }
            System.out.println("Subscription_Cost deserialized successfully.");
        } catch (IOException | NumberFormatException e) {
            System.out.println("Error during deserialization of Subscription_Cost: " + e.getMessage());
        }
        
        try (BufferedReader reader = new BufferedReader(new FileReader("/Users/ahmedosama/NetBeansProjects/JavaApplication4/MembershipPlanrFiles/SubscribedCustomerIDcopy.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.isEmpty()) {
                SubscribedCustomerIDcopy.add(Integer.parseInt(line));
                }
            }
            System.out.println("SubscribedCustomerIDcopy deserialized successfully.");
        } catch (IOException | NumberFormatException e) {
            System.out.println("Error during deserialization of SubscribedCustomerIDcopy: " + e.getMessage());
        }
        
        try (BufferedReader reader = new BufferedReader(new FileReader("/Users/ahmedosama/NetBeansProjects/JavaApplication4/MembershipPlanrFiles/Subscription_Date.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                Subscription_Date.add(line);
            }
            System.out.println("Subscription_Date deserialized successfully.");
        } catch (IOException e) {
            System.out.println("Error during deserialization of v: " + e.getMessage());
        }
    }
}
